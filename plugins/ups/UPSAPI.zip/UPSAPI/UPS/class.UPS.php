<?php

class UPS {

	const UPS_API_DEV	= 'https://wwwcie.ups.com/ups.app/xml/Rate';
	const UPS_API_PROD	= 'https://www.ups.com/ups.app/xml/Rate';

	// The ship types we are going to use (returned as Service/Code in the UPS XML).
	// Others are listed in the UPS API manual.
	protected static $ship_types = array(
		'01',	// Next Day Air
		'02',	// 2nd Day Air
		'03'	// Ground
	);

	public function __construct () {
	}


	public function runTest () {
		$data = file_get_contents('./UPS/partial.AccessRequest.xml.php');
		$data .= file_get_contents('./UPS/partial.RSSRequest.xml.php');

		$params = array(
			'LICENSE_NUMBER'	=> '',	// Personal license number assigned by UPS OnLine Tools goes here.
			'FROM_ZIP'			=> '97214',
			'TO_ZIP'			=> '60123',
			'PACKAGE_WEIGHT'	=> '33'
		);

		foreach ($params as $key => $val) {
			$data = str_replace('{'.$key.'}', $val, $data);
		}

		$xmlResults = $this->doRequest(self::UPS_API_DEV, $data);

	    $simpleResults = simplexml_load_string($xmlResults);

		// For debugging UPS's XML:
		//	echo '<pre>';
		//	print htmlentities($xmlResults);
		//	echo '</pre>';

		var_dump($simpleResults);
	}


	/**
	 * doRequest
	 * ~~~~~~~~~
	 * Params:
	 *	$url		- The full URL to send the request to.
	 *	$request	- The request string to be sent via POST to the URL.
	 */
	public function doRequest ($url, $request)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $request);

		$data = curl_exec($ch);

		if (curl_errno($ch)) {
			print curl_error($ch);
		} else {
			curl_close($ch);
		}

		return $data;
	}

}

?>
