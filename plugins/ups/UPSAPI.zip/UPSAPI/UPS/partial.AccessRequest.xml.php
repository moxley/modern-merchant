<?xml version="1.0"?>
<AccessRequest xml:lang="en-US">
   <AccessLicenseNumber>{LICENSE_NUMBER}</AccessLicenseNumber>
   <UserId>testUser</UserId>
   <Password>testPW</Password>
</AccessRequest>