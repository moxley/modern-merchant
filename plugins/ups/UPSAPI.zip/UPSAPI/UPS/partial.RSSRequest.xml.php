<?xml version="1.0"?>
<RatingServiceSelectionRequest xml:lang="en-US">
  <Request>
	<TransactionReference>
	  <CustomerContext>Rating and Service</CustomerContext>
	  <XpciVersion>1.0001</XpciVersion>
	</TransactionReference>
	<RequestAction>Rate</RequestAction>
	<RequestOption>shop</RequestOption>
  </Request>
  <PickupType>
  <Code>01</Code>
  </PickupType>
  <Shipment>
	<Shipper>
	  <Address>
	<PostalCode>{FROM_ZIP}</PostalCode>
	  </Address>
	</Shipper>
	<ShipTo>
	  <Address>
	<PostalCode>{TO_ZIP}</PostalCode>
	  </Address>
	</ShipTo>
	<Package>
	  <PackagingType>
		<Code>02</Code>
		<Description>Package</Description>
	  </PackagingType>
	  <Description>Rate Shopping</Description>
	  <PackageWeight>
		<Weight>{PACKAGE_WEIGHT}</Weight>
	  </PackageWeight>
	 </Package>
	<ShipmentServiceOptions>
		<SaturdayDeliveryIndicator>1</SaturdayDeliveryIndicator>
	</ShipmentServiceOptions>
  </Shipment>
</RatingServiceSelectionRequest>
