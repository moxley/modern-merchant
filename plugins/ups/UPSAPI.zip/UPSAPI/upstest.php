<?php

	include('./UPS/class.UPS.php');

	$ups = new UPS();

	$ups->runTest();

?>